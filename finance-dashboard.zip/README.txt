Finance Dashboard Project

Features:

1. Dashboard Overview
2. Transaction Management
3. Role Based UI
4. Insights Section
5. State Management using JavaScript
6. Dark Mode
7. Data Persistence using LocalStorage
8. CSV Export Feature

Technology Used:

HTML
CSS
JavaScript

How to Run:

Open index.html in browser.
Add transactions to view insights.
Select Admin role to export CSV.
Use Dark Mode button to change theme.