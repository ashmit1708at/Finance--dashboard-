let transactions =
JSON.parse(localStorage.getItem("transactions")) || [];

const descInput =
document.getElementById("desc");

const amountInput =
document.getElementById("amount");

const typeInput =
document.getElementById("type");

const addBtn =
document.getElementById("addBtn");

const tableBody =
document.getElementById("tableBody");

const roleSelect =
document.getElementById("roleSelect");

const darkBtn =
document.getElementById("darkBtn");

const exportBtn =
document.getElementById("exportBtn");


// Add Transaction

addBtn.onclick = function () {

const desc =
descInput.value;

const amount =
parseInt(amountInput.value);

const type =
typeInput.value;

if (desc === "" || isNaN(amount)) {

alert("Enter valid data");

return;

}

const transaction = {

desc: desc,

amount: amount,

type: type

};

transactions.push(transaction);

saveData();

renderTransactions();

updateInsights();

descInput.value = "";

amountInput.value = "";

};


// Save Data

function saveData() {

localStorage.setItem(
"transactions",
JSON.stringify(transactions)
);

}


// Render Table

function renderTransactions() {

tableBody.innerHTML = "";

transactions.forEach(function (t) {

tableBody.innerHTML +=

"<tr>" +

"<td>" + t.desc + "</td>" +

"<td>" + t.amount + "</td>" +

"<td>" + t.type + "</td>" +

"</tr>";

});

}


// Update Insights

function updateInsights() {

let income = 0;

let expense = 0;

transactions.forEach(function (t) {

if (t.type === "income") {

income += t.amount;

} else {

expense += t.amount;

}

});

document.getElementById(
"totalIncome"
).textContent = income;

document.getElementById(
"totalExpense"
).textContent = expense;

document.getElementById(
"balance"
).textContent = income - expense;

}


// Role Based UI

roleSelect.onchange = function () {

if (roleSelect.value === "admin") {

alert("Admin Mode");

exportBtn.style.display =
"inline-block";

} else {

alert("User Mode");

exportBtn.style.display =
"none";

}

};


// Dark Mode

darkBtn.onclick = function () {

document.body.classList.toggle("dark");

};


// Export CSV

exportBtn.onclick = function () {

let csv =
"Description,Amount,Type\n";

transactions.forEach(function (t) {

csv +=

t.desc + "," +

t.amount + "," +

t.type + "\n";

});

let blob =
new Blob([csv]);

let a =
document.createElement("a");

a.href =
URL.createObjectURL(blob);

a.download =
"transactions.csv";

a.click();

};


// Run on Start

renderTransactions();

updateInsights();